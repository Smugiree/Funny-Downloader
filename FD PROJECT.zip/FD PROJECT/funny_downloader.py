import tkinter as tk
from tkinter import *
from tkinter import messagebox as message
from pytube import YouTube
import os
from pathlib import Path

isvideo = True

def turn_audio():
    global isvideo
    isvideo = False

def turn_video():
    global isvideo
    isvideo = True

def download():
    print(isvideo)

    if(isvideo == True):
        link = textbox.get("1.0","end-1c")
        print(link)
        vid = YouTube(link)
        YouTube(link).streams.get_highest_resolution().download(os.path.join(Path.home(), 'Downloads'))

    if(isvideo == False):
        link = textbox.get("1.0","end-1c")
        print(link)
        vid = YouTube(link)
        
        video = YouTube(link).streams.filter(only_audio=True).first()
        destination = str(os.path.join(Path.home(), 'Downloads'))
        out_file = video.download(output_path=destination)
        base, ext = os.path.splitext(out_file)
        new_file = base + '.mp3'
        os.rename(out_file, new_file)

    message.showinfo(message="Your video/audio is ready! (check your downloads folder)")

#main window
window = tk.Tk()
window.geometry("400x110")
window.title("Funny Downloader 0.6 CONSOLE")
window.resizable(False, False)

#text and windows
label = tk.Label(window, text="Funny Downloader", font=('Arial', 18))
label.place(relx= -0.001, rely= -0.005)

textbox = tk.Text(window, font=('Arial', 13), height=1, width=43)
textbox.place(relx=0.005, rely=0.3);

video = tk.Button(window, text="video", font=('Arial', 15), height=1, width=9, command=turn_video)
video.place(relx=0.005, rely=0.56);

audio = tk.Button(window, text="audio", font=('Arial', 15), height=1, width=9, command=turn_audio)
audio.place(relx=0.3, rely=0.56);

start = tk.Button(window, text="start", font=('Arial', 15), height=1, width=9, command=download)
start.place(relx=0.72, rely=0.56);

window.mainloop()